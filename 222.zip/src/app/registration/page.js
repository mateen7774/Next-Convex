import Registration from "../components/Registration";
export default Registration;
