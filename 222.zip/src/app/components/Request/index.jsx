"use client";
import "./request.css";
import React, { useState, useEffect } from "react";

import Layout from "../Shared/layout";
import Image from "next/image";
import Link from "next/link";

import {
  MagnifyingGlassIcon,
  Bars3BottomLeftIcon,
} from "@heroicons/react/24/outline";

import { useMutation, useQuery } from "convex/react";
import { api } from "../../../../convex/_generated/api";
import toast, { Toaster } from "react-hot-toast";

const cardData = [
  {
    id: 1,
    requestAmount: "50 €",
    deliveryDate: "Fri 03/12/24",
    deliveryTime: "8h - 10h",
    biddingTime: "48h",
    timeout: "0hr 49m",
    isExpired: true,
  },
  {
    id: 1,
    requestAmount: "50 €",
    deliveryDate: "Fri 02/23/24",
    deliveryTime: "8h - 10h",
    biddingTime: "40h",
    timeout: "1hr 49m",
    isExpired: true,
  },
  {
    id: 1,
    requestAmount: "50 €",
    deliveryDate: "Fri 02/23/24",
    deliveryTime: "8h - 10h",
    biddingTime: "48h",
    timeout: "1hr 49m",
  },
  {
    id: 1,
    requestAmount: "50 €",
    deliveryDate: "Fri 02/23/24",
    deliveryTime: "8h - 10h",
    biddingTime: "48h",
    timeout: "1hr 49m",
  },
  {
    id: 1,
    requestAmount: "50 €",
    deliveryDate: "Fri 02/23/24",
    deliveryTime: "8h - 10h",
    biddingTime: "48h",
    timeout: "1hr 49m",
    isExpired: true,
  },
  {
    id: 1,
    requestAmount: "50 €",
    deliveryDate: "Fri 02/23/24",
    deliveryTime: "8h - 10h",
    biddingTime: "48h",
    timeout: "1hr 49m",
  },
  {
    id: 1,
    requestAmount: "50 €",
    deliveryDate: "Fri 02/23/24",
    deliveryTime: "8h - 10h",
    biddingTime: "48h",
    timeout: "1hr 49m",
  },
  {
    id: 1,
    requestAmount: "50 €",
    deliveryDate: "Fri 02/23/24",
    deliveryTime: "8h - 10h",
    biddingTime: "48h",
    timeout: "1hr 49m",
  },
  {
    id: 1,
    requestAmount: "50 €",
    deliveryDate: "Fri 02/23/24",
    deliveryTime: "8h - 10h",
    biddingTime: "48h",
    timeout: "1hr 49m",
  },
];

const RequestCard = ({ data }) => {
  const [timeLeft, setTimeLeft] = useState("");
  const [isPastDelivery, setIsPastDelivery] = useState(false);
  const [isLessThanAnHour, setIsLessThanAnHour] = useState(false);

  function formatBiddingTime(biddingTime) {
    const hours = parseInt(biddingTime);

    if (hours < 48) {
      return "h-m-s";
    } else {
      return biddingTime;
    }
  }

  const timeStyle = {
    color: isLessThanAnHour ? "red" : "inherit",
  };

  useEffect(() => {
    const deliveryDateTimeStr = `${
      data.deliveryDate
    } ${data.deliveryTime.toUpperCase()}`;
    const deliveryDateTime = new Date(deliveryDateTimeStr);

    const now = new Date();
    if (now > deliveryDateTime) {
      setIsPastDelivery(true);
    } else {
      const timeoutParts = data.timeout.match(/(\d+)hr (\d+)m/);
      let hours = timeoutParts ? parseInt(timeoutParts[1], 10) : 0;
      let minutes = timeoutParts ? parseInt(timeoutParts[2], 10) : 0;
      let totalSeconds = hours * 3600 + minutes * 60;

      const timer = setInterval(() => {
        totalSeconds -= 1; // Decrement by one second

        const hoursLeft = Math.floor(totalSeconds / 3600);
        const minutesLeft = Math.floor((totalSeconds % 3600) / 60);
        const secondsLeft = totalSeconds % 60;

        setTimeLeft(`${hoursLeft}hr ${minutesLeft}m ${secondsLeft}s`);
        setIsLessThanAnHour(totalSeconds < 3600);
        if (totalSeconds <= 0) {
          clearInterval(timer);
        }
      }, 1000); // Update every second

      return () => clearInterval(timer);
    }
  }, [data.timeout, data.deliveryDate, data.deliveryTime]);

  if (isPastDelivery) {
    return null;
  }

  return (
    <Link href={`/requests/${data._id}`}>
      <div
        style={{ fontFamily: "Oakes Grotesk Medium" }}
        className="bg-white w-full mb-5 rounded-xl border border-gray-200 shadow-md p-4"
      >
        <div className="flex justify-between items-center mb-5">
          <span>Request for max. {data.requestAmount}</span>
          {data.isExpired ? (
            <button className="px-4 py-1 bg-[linear-gradient(to_right,#989898,#4F4F4F)] text-white text-sm font-medium rounded-full">
              Expire
            </button>
          ) : (
            <button className="flex items-center justify-center  px-4 py-1  bg-[linear-gradient(to_right,#428FF5,#0064E8)] text-white text-sm rounded-full">
              New
            </button>
          )}
        </div>
        <div className="flex justify-between text-sm mb-5">
          <div className="flex items-center">
            <Image
              src="/truck-time.svg"
              alt="Rocket Market Logo"
              width={16}
              height={16}
            />
            <span className="ml-1">
              <span style={{ fontWeight: 400 }}>To Deliver</span>{" "}
              {data.deliveryDate}
            </span>
          </div>
          <div className="flex items-center">
            <Image
              src="/ruler.svg"
              alt="Rocket Market Logo"
              width={16}
              height={16}
            />
            <span className="ml-1">
              <span style={{ fontWeight: 400 }}>Between</span>{" "}
              {data.deliveryTime}
            </span>
          </div>
        </div>

        <div className="flex justify-between text-sm">
          <div className="flex items-center ">
            <Image
              src="/brifecase-timer.svg"
              alt="Rocket Market Logo"
              width={16}
              height={16}
            />
            <span className="ml-1">
              <span style={{ fontWeight: 400 }} className="mr-3">
                Bidding Time
              </span>
              {formatBiddingTime(data.biddingTime)}
            </span>
          </div>
          <div className="flex items-center">
            <Image
              src="/security-time.svg"
              alt="Rocket Market Logo"
              width={16}
              height={16}
            />
            <span className="ml-1">
              {" "}
              <span style={{ fontWeight: 400 }} className="mr-1">
                Timeout
              </span>{" "}
              <span style={timeStyle}> {timeLeft}</span>
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
};

const Request = () => {
  const getBasket = useQuery(api.getRequest.getRequest);
  const [activeTab, setActiveTab] = useState("all");

  const tabClass = (tabName) =>
    `px-4 py-2 rounded-full text-sm font-medium focus:outline-none ${
      activeTab === tabName
        ? "bg-[linear-gradient(to_right,#428FF5,#0064E8)] text-white"
        : "text-custom-gray "
    }`;

  const filteredCardData = getBasket?.filter((card) => {
    if (activeTab === "all") return true;
    if (activeTab === "new" && !card.isExpired) return true;
    if (activeTab === "expire" && card.isExpired) return true;
    return false;
  });

  console.log("getBasket", getBasket);

  return (
    <>
      <Layout>
        <div
          style={{ fontFamily: "Oakes Grotesk Medium" }}
          className="container mx-auto my-10 px-4 md:px-6"
        >
          <div className="container  mb-10">
            <div className="flex justify-between items-center">
              <div className="flex space-x-2">
                <button
                  onClick={() => setActiveTab("all")}
                  className={tabClass("all")}
                >
                  All
                </button>
                <button
                  onClick={() => setActiveTab("new")}
                  className={tabClass("new")}
                >
                  New
                </button>
                <button
                  onClick={() => setActiveTab("expire")}
                  className={tabClass("expire")}
                >
                  Expire
                </button>
              </div>
              {/* Increased text size */}
              <div className="flex items-center justify-center flex-row gap-5">
                <div className="hidden md:flex items-center justify-center flex-row rounded-full bg-white shadow-md">
                  <input
                    type="search"
                    className="pl-6 pr-2 py-2 w-40 rounded-full text-sm focus:outline-none"
                    placeholder="Search..."
                  />
                  <div className="p-2">
                    <MagnifyingGlassIcon className="w-5 h-5 text-gray-500" />
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {/* Vertical Bars Icon leaning left */}
                  <button className="rounded-full bg-white p-2">
                    <Image
                      src="/setting-5.svg"
                      alt="Rocket Market Logo"
                      width={24}
                      height={24}
                    />
                  </button>
                </div>
              </div>
            </div>
            <hr className="border-gray-300 mt-4" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mx-auto">
            {filteredCardData?.map((data, index) => (
              <div key={index} className="px-2">
                <RequestCard data={data} />
              </div>
            ))}
          </div>
        </div>
      </Layout>
    </>
  );
};

export default Request;
