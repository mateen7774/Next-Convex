import React from "react";
import Image from "next/image";

const Home = () => {
  return (
    <div
      style={{ fontFamily: "Oakes Grotesk Medium" }}
      className="flex justify-between items-center p-10 min-h-full bg-gradient-radial mt-12"
    >
      {/* Text Section */}
      <div className="max-w-md">
        <h1 className="text-3xl mb-6">
          Lorem ipsum dolor sit amet consectetur.
        </h1>
        <p className="mb-6 text-1xl">
          Lorem ipsum dolor sit amet consectetur. Egestas suscipit elementum
          tellus sit viverra bibendum arcu et vestibulum. Viverra duis atque
          quam quam fugiat facilis elementum menacenass.
        </p>
        <button className="bg-[linear-gradient(to_right,#428FF5,#0064E8)] text-white px-6 py-2 rounded hover:bg-blue-700 transition duration-300 rounded-lg">
          Get Started
        </button>
      </div>

      {/* Image Section */}
      <div className="hidden md:block">
        <Image
          src="/Layer1.svg"
          alt="Construction Illustration"
          width={500}
          height={400}
          layout="responsive"
        />
      </div>
    </div>
  );
};

export default Home;
