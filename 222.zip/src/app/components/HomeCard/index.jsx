import React from "react";

import { MagnifyingGlassIcon } from "@heroicons/react/24/outline";
import Layout from "../Shared/layout";

const cardsData = [
  {
    id: 1,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 1,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 1,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 1,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 1,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 1,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 1,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 1,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 1,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 1,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
];

const Card = ({ title, description, imageUrl }) => {
  return (
    <div
      style={{ fontFamily: "Oakes Grotesk Medium" }}
      className="bg-white shadow shadow-md rounded-xl overflow-hidden border border-slate-300"
    >
      <img className="w-full h-30 object-cover" src={imageUrl} alt={title} />
      <div className="p-4">
        <h5 className="text-md  mt-1 mb-4">{title}</h5>
        <p className="text-xs">{description}</p>
      </div>
    </div>
  );
};

const HomeCard = () => {
  return (
    <Layout>
      <div
        style={{ fontFamily: "Oakes Grotesk Medium" }}
        className="container mx-auto my-10 px-4 md:px-0"
      >
        <div className="mb-10">
          <div className="flex justify-between items-center">
            <h1
              className="text-3xl"
              style={{ fontWeight: "500 !important", color: "#444444" }}
            >
              Home
            </h1>
            <div className="flex items-center rounded-full bg-white shadow-md">
              <input
                type="search"
                className="pl-6 pr-2 py-2 w-40 rounded-full text-sm focus:outline-none"
                placeholder="Search..."
              />
              <div className="p-2">
                <MagnifyingGlassIcon className="w-5 h-5 text-gray-500" />
              </div>
            </div>
          </div>
          <hr className="border-gray-300 mt-4" />
        </div>

        <div className="mb-10">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-10 md:gap-4">
            {cardsData.map((card) => (
              <Card
                key={card.id}
                title={card.title}
                description={card.description}
                imageUrl={card.imageUrl}
              />
            ))}
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default HomeCard;
