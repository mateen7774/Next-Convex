"use client";
import React, { useState } from "react";

import Slider from "react-slick";
import Image from "next/image";

import Layout from "../Shared/layout";
import { useParams } from "next/navigation";

import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import { useMutation, useQuery } from "convex/react";
import { api } from "../../../../convex/_generated/api";

import { useConvexAuth } from "convex/react";
import toast, { Toaster } from "react-hot-toast";

const InsulationProduct = () => {
  const params = useParams();
  const materialMajor = params.productId;

  const materialCombinations = useQuery(api.products.getCombinations, {
    materialMajor,
  });

  const placeOrderFn = useMutation(api.placeOrder.placeOrder);
  console.log(materialCombinations, "sd");

  const [standard, setStandard] = useState("NF");
  const [thickness, setThickness] = useState("BA10");
  const [dimension, setDimension] = useState("250x120");
  const [option, setOption] = useState("HYDRO");
  const [quantity, setQuantity] = useState(1);

  const [parameters, setParameters] = useState([]);
  const [selectedValues, setSelectedValues] = useState({});

  const slidesData = [
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 1",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 1",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 1",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 1",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 1",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 2",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 2",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 2",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 2",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 2",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 2",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 2",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 2",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 2",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 2",
    },
    {
      src: "/Rectangle 4.png",
      alt: "Drywall 2",
    },
  ];

  const CustomArrow = ({ className, style, onClick, arrow }) => (
    <button
      className={className}
      style={{
        ...style,
        display: "block",
        background: "transparent",
        color: "#000",
        fontSize: "24px",
        lineHeight: "1",
        zIndex: "2",
        position: "absolute",
        top: "50%",
        transform: "translate(0, -50%)",
        ...(arrow === ">" ? { right: "10px" } : { left: "10px" }),
      }}
      onClick={onClick}
      aria-label={arrow === "<" ? "Previous" : "Next"}
    ></button>
  );

  const settings = {
    dots: false,
    infinite: true,
    speed: 500,
    slidesToShow: 7,
    slidesToScroll: 6,
    nextArrow: <CustomArrow arrow=">" />,
    prevArrow: <CustomArrow arrow="<" />,
    centerMode: true,
    centerPadding: "50px",
    responsive: [
      {
        breakpoint: 768, // Tailwind's md breakpoint
        settings: {
          slidesToShow: 3,
          slidesToScroll: 3,
          // You can adjust other settings for this breakpoint as needed
        },
      },
      // You can add more breakpoints here if needed
    ],
  };

  const handleSelectionChange = (parameterName, value) => {
    setSelectedValues((prevValues) => ({
      ...prevValues,
      [parameterName]: value,
    }));
  };

  console.log("selectedValues", selectedValues);

  const placeToOrder = async () => {
    try {
      await placeOrderFn({
        estimatedPrice: materialCombinations[0].estimatedPrice,
        materialMajor: materialCombinations[0].materialMajor,
        minorDescription: materialCombinations[0].minorDescription,
        minorName: materialCombinations[0].minorName,
      });
      toast.success("order placed successfully");
    } catch (error) {
      toast.error("order placed failed");
    }
  };
  return (
    <Layout>
      <Toaster />
      <div
        style={{ color: "#444444", fontFamily: "Oakes Grotesk Medium" }}
        className="container mx-auto p-4 bg-white rounded-xl shadow-md my-5"
      >
        {materialCombinations?.map((item, index) => {
          return (
            <div key={index} className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="md:w-full ">
                <Image
                  src="/Rectangle2.png"
                  alt="Construction Illustration"
                  width={600}
                  height={400}
                  layout="responsive"
                />
              </div>
              <div className="p-6 max-w-2xl mx-auto space-x-4">
                <div className="flex flex-col">
                  <h2 className="text-3xl">{item.minorName}</h2>

                  <p className=" text-gray-500 text-sm my-4">
                    {item.minorDescription}
                  </p>

                  {/* <div className="">
                    <div className="mb-3">
                      <span>Standards</span>
                      <div className="mt-2">
                        <label className="inline-flex items-center">
                          <input
                            type="radio"
                            className="form-radio"
                            name="standard"
                            value="CE"
                            checked={standard === "CE"}
                            onChange={() => setStandard("CE")}
                          />
                          <span className="ml-2  text-xs">CE</span>
                        </label>
                        <label className="inline-flex items-center ml-10">
                          <input
                            type="radio"
                            className="form-radio"
                            name="standard"
                            value="NF"
                            checked={standard === "NF"}
                            onChange={() => setStandard("NF")}
                          />
                          <span className="ml-2 text-xs">NF</span>
                        </label>
                      </div>
                    </div>

                    <div className="mb-3">
                      <span className="">Thickness</span>
                      <div className="mt-2">
                        <label className="inline-flex items-center">
                          <input
                            type="radio"
                            className="form-radio"
                            name="thickness"
                            value="BA13"
                            checked={thickness === "BA13"}
                            onChange={() => setThickness("BA13")}
                          />
                          <span className="ml-2 text-xs">BA13</span>
                        </label>
                        <label className="inline-flex items-center ml-6">
                          <input
                            type="radio"
                            className="form-radio"
                            name="thickness"
                            value="BA10"
                            checked={thickness === "BA10"}
                            onChange={() => setThickness("BA10")}
                          />
                          <span className="ml-2  text-xs">BA10</span>
                        </label>
                      </div>
                    </div>

                    <div className="mb-3">
                      <span className="">Dimension</span>
                      <div className="mt-2">
                        <label className="inline-flex items-center">
                          <input
                            type="radio"
                            className="form-radio"
                            name="dimension"
                            value="250x120"
                            checked={dimension === "250x120"}
                            onChange={() => setDimension("250x120")}
                          />
                          <span className="ml-2 text-xs">
                            250x120 cm<sup>2</sup>
                          </span>
                        </label>
                        <label className="inline-flex items-center ml-3">
                          <input
                            type="radio"
                            className="form-radio"
                            name="dimension"
                            value="125x60"
                            checked={dimension === "125x60"}
                            onChange={() => setDimension("125x60")}
                          />
                          <span className="ml-2 text-xs">
                            125x60 cm<sup>2</sup>
                          </span>
                        </label>

                        <label className="inline-flex items-center ml-3">
                          <input
                            type="radio"
                            className="form-radio"
                            name="dimension"
                            value="260x120"
                            checked={dimension === "260x120"}
                            onChange={() => setDimension("260x120")}
                          />
                          <span className="ml-2 text-xs">
                            260x120cm<sup>2</sup>
                          </span>
                        </label>

                        <label className="inline-flex items-center ml-3">
                          <input
                            type="radio"
                            className="form-radio"
                            name="dimension"
                            value=" 280x120"
                            checked={dimension === " 280x120"}
                            onChange={() => setDimension(" 280x120")}
                          />
                          <span className="ml-2 text-xs">
                            280x120 cm<sup>2</sup>
                          </span>
                        </label>

                        <label className="inline-flex items-center ml-3">
                          <input
                            type="radio"
                            className="form-radio"
                            name="dimension"
                            value="300x120"
                            checked={dimension === "300x120"}
                            onChange={() => setDimension("300x120")}
                          />
                          <span className="ml-2 text-xs">
                            300x120 cm<sup>2</sup>
                          </span>
                        </label>

                        <label className="inline-flex items-center ">
                          <input
                            type="radio"
                            className="form-radio"
                            name="dimension"
                            value="300x120"
                            checked={dimension === "300x120"}
                            onChange={() => setDimension("300x120")}
                          />
                          <span className=" ml-2 text-xs">
                            300x120 cm<sup>2</sup>
                          </span>
                        </label>
                      </div>
                    </div>

                    <div className="mb-2">
                      <span className="text-gray-700">Dimension</span>
                      <div className="mt-2">
                        <label className="inline-flex items-center">
                          <input
                            type="radio"
                            className="form-radio"
                            name="option"
                            value="none"
                            checked={option === "none"}
                            onChange={() => setOption("none")}
                          />
                          <span className="ml-2 text-xs">None</span>
                        </label>
                        <label className="inline-flex items-center ml-3">
                          <input
                            type="radio"
                            className="form-radio"
                            name="option"
                            value="HYDRO"
                            checked={option === "HYDRO"}
                            onChange={() => setOption("HYDRO")}
                          />
                          <span className="ml-2 text-xs">HYDRO</span>
                        </label>
                      </div>
                    </div>
                  </div> */}

                  <div>
                    {item.parameters.map(({ name, value }) => (
                      <div key={name} className="mb-3">
                        <span className="">{name}</span>
                        <div className="mt-2">
                          <label className="inline-flex items-center">
                            <input
                              type="radio"
                              className="form-radio"
                              name={name}
                              value={value}
                              checked={selectedValues[name] === value}
                              onChange={() =>
                                handleSelectionChange(name, value)
                              }
                            />
                            <span className="ml-2 text-xs">{value}</span>
                          </label>
                        </div>
                      </div>
                    ))}
                  </div>

                  <div className=" mt-2">
                    <h2 className="text-1xl">QTY</h2>
                    <button
                      className=" text-black mr-5"
                      onClick={() => setQuantity(Math.max(1, quantity - 1))}
                      disabled={quantity <= 1}
                    >
                      -
                    </button>
                    <span className="text-gray-700 text-lg">{quantity}</span>
                    <button
                      className=" text-black ml-5"
                      onClick={() => setQuantity(quantity + 1)}
                    >
                      +
                    </button>
                  </div>

                  <button
                    onClick={() => placeToOrder(item)}
                    className="bg-[linear-gradient(to_right,#428FF5,#0064E8)] text-white px-4 py-2 mt-4 w-fit"
                  >
                    Place to Order
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div>
        <div
          className="container mx-auto  pb-5  bg-white rounded-xl shadow-md my-5"
          style={{ position: "relative" }}
        >
          <p className="pt-2 px-3">More Products</p>
          <div className="pt-3 px-5">
            <Slider {...settings}>
              {slidesData.map((slide) => (
                <div key={slide.alt} className="p-2">
                  <div className="bg-white rounded-xl shadow-md overflow-hidden">
                    <Image
                      src={slide.src}
                      alt="Construction Illustration"
                      width={134}
                      height={75}
                      layout="responsive"
                    />
                    <div className="py-4 pl-2">
                      <p className=" text-gray-500 text-sm">Drywall</p>
                    </div>
                  </div>
                </div>
              ))}
            </Slider>
          </div>
        </div>
      </div>
    </Layout>
  );
};

export default InsulationProduct;
