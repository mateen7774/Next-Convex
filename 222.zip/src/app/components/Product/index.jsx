"use client";
import "./product.css";
import React, { useState } from "react";
import Link from "next/link";
import Image from "next/image";
import { MagnifyingGlassIcon } from "@heroicons/react/24/outline";
import Layout from "../Shared/layout";

import { useMutation, useQuery } from "convex/react";
import { api } from "../../../../convex/_generated/api";

import { useConvexAuth } from "convex/react";

// Replace with your actual data
const cardsData = [
  {
    id: 1,
    title: "Polystyrene insulation",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 2,
    title: "Drywall",

    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 3,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 4,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 5,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 6,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 7,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 8,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 9,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
  {
    id: 10,
    title: "Cement",
    description:
      "A binder, a chemical substance used for construction that sets, hardens, and adheres to other materials to bind them together.",
    imageUrl: "/cardImage.png",
  },
];

const Card = ({ id, title, description, imageUrl }) => {
  return (
    <Link href={`/products/${id}`}>
      <div
        style={{ fontFamily: "Oakes Grotesk Medium" }}
        className="bg-white shadow shadow-md rounded-xl overflow-hidden border border-slate-300"
      >
        <img
          className="w-full h-30 object-cover"
          src="/cardImage.png"
          alt="productImage"
        />
        <div className="p-4">
          <h5 className="text-md mt-1 mb-4">{title}</h5>
          <p className="text-xs">{description}</p>
        </div>
      </div>
    </Link>
  );
};

const Prodcuct = () => {
  const { isLoading, isAuthLoading, isAuthenticated } = useConvexAuth();

  const getProduct = useQuery(api.products.getProductUser);

  const [activeTab, setActiveTab] = useState("all");

  const tabClass = (tabName) =>
    `px-4 py-2 text-sm font-medium focus:outline-none ${
      activeTab === tabName
        ? "bg-gradient text-white rounded-full"
        : "text-custom-gray"
    }`;

  console.log("getProduct", getProduct);

  const filterCards = () => {
    if (activeTab === "all") {
      return getProduct;
    } else {
      return getProduct.filter((card) => card.title === activeTab);
    }
  };

  return (
    <Layout>
      <div
        style={{ fontFamily: "Oakes Grotesk Medium" }}
        className="container mx-auto my-10 px-4 md:px-0"
      >
        <div className="container  mb-10">
          <div className="flex justify-between items-center">
            <div className="flex items-center ">
              <button
                onClick={() => setActiveTab("all")}
                className={`${tabClass(
                  "all"
                )} text-xs sm:text-sm md:text-base p-2 sm:p-3`}
              >
                All
              </button>
              <button
                onClick={() => setActiveTab("Cement")}
                className={`${tabClass(
                  "Cement"
                )} text-xs sm:text-sm md:text-base p-2 sm:p-3`}
              >
                Cement
              </button>
              <button
                onClick={() => setActiveTab("Drywall")}
                className={`${tabClass(
                  "Drywall"
                )} text-xs sm:text-sm md:text-base p-2 sm:p-3`}
              >
                Drywall
              </button>

              <button
                onClick={() => setActiveTab("Polystyrene insulation")}
                className={`${tabClass(
                  "Polystyrene insulation"
                )} text-xs  sm:text-sm md:text-base p-2 sm:p-3`}
              >
                Polystyrene insulation
              </button>
            </div>

            <div className="flex items-center ">
              <div className="hidden md:flex items-center rounded-full bg-white shadow-md space-x-2">
                <input
                  type="search"
                  className="pl-6 pr-2 py-2 w-40 rounded-full text-sm focus:outline-none"
                  placeholder="Search..."
                />
                <div className="p-2">
                  <MagnifyingGlassIcon className="w-5 h-5 text-gray-500" />
                </div>
              </div>
              <button className="rounded-full bg-white p-2 ml-4">
                <Image
                  src="/setting-5.svg"
                  alt="Rocket Market Logo"
                  width={24}
                  height={24}
                />
              </button>
            </div>
          </div>

          <hr className="border-gray-300 mt-4" />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 md:gap-4">
          {filterCards()?.map((card) => (
            <Card
              key={card.materialMajor}
              id={card.materialMajor}
              title={card.title}
              description={card.description}
            />
          ))}
        </div>
      </div>
    </Layout>
  );
};

export default Prodcuct;
