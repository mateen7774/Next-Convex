"use client";
import React, { useState } from "react";
import Layout from "../Shared/layout";

const GetRequest = () => {
  const [offer, setOffer] = useState("");
  const [comments, setComments] = useState("");

  const handleSubmit = (event) => {
    event.preventDefault();
    console.log(`Offer: ${offer}, Comments: ${comments}`);
  };

  return (
    <>
      <Layout>
        <div
          style={{ fontFamily: "Oakes Grotesk Medium" }}
          className="container mx-auto my-7 px-4 md:px-4"
        >
          <div className="container  mb-10">
            <div className="flex justify-between items-center">
              <h1
                className="text-3xl"
                style={{ fontWeight: "500 !important", color: "#444444" }}
              >
                Request
              </h1>{" "}
            </div>
            <hr className="border-gray-300 mt-4" />
          </div>
        </div>

        <div className="container mx-auto my-7 px-4 md:px-4">
          <form
            onSubmit={handleSubmit}
            className="bg-white shadow-lg rounded-lg p-8  w-full"
          >
            <h2 className="text-xl  text-gray-800 mb-4 flex items-center">
              Request for max.
              <span className=" ml-2">50 €</span>
              <span className="ml-5 px-4 py-1 bg-custom-new text-white text-sm font-medium rounded-full">
                New
              </span>
            </h2>

            {/* DESKTOP DIV */}
            <div className="hidden md:flex flex flex-col md:flex-row md:items-center gap-2 md:gap-20 mb-4">
              <div className="flex items-center">
                <img src="/truck-time.svg" />
                <span className="text-gray-700 text-sm">To Deliver</span>
                <span className="text-sm  ml-2">Fri,02/03/24</span>
              </div>
              <div className="flex items-center">
                <img src="/ruler.svg" />
                <span className="text-gray-700 text-sm">Between</span>
                <span className="text-sm  ml-2">8h - 10h</span>
              </div>
              <div className="flex items-center">
                <img src="/brifecase-timer.svg" />
                <span className="text-gray-700 text-sm">Bidding Time</span>
                <span className="text-sm  ml-2">48h</span>
              </div>
              <div className="flex items-center">
                <img src="/security-time.svg" />
                <span className="text-gray-700 text-sm">Timeout</span>
                <span className="text-sm  ml-2">1h 44m</span>
              </div>
            </div>
            {/* DESKTOP DIV */}
            {/* Mobile Div */}
            <div className="flex md:hidden flex-col md:flex-row justify-between gap-2 my-10">
              <div className="flex items-center justify-between md:justify-start">
                <div className="flex items-center">
                  <img src="/truck-time.svg" alt="Delivery Truck" />
                  <span className="text-gray-700 text-sm">To Deliver</span>
                  <span className="text-sm ml-2">Fri,02/03/24</span>
                </div>
                <div className="flex items-center">
                  <img src="/ruler.svg" alt="Ruler" />
                  <span className="text-gray-700 text-sm">Between</span>
                  <span className="text-sm ml-2">8h - 10h</span>
                </div>
              </div>
              <div className="flex items-center justify-between md:justify-start">
                <div className="flex items-center">
                  <img src="/brifecase-timer.svg" alt="Bidding Time" />
                  <span className="text-gray-700 text-sm">Bidding Time</span>
                  <span className="text-sm ml-2">48h</span>
                </div>
                <div className="flex items-center">
                  <img src="/security-time.svg" alt="Timeout" />
                  <span className="text-gray-700 text-sm">Timeout</span>
                  <span className="text-sm ml-2">1h 44m</span>
                </div>
              </div>
            </div>

            {/* Mobile Div */}

            <div className="mb-4 flex flex-col">
              <label htmlFor="offer" className="text-gray-700 text-sm ">
                Your offer
              </label>
              <input
                type="text"
                id="offer"
                name="offer"
                value={offer}
                onChange={(e) => setOffer(e.target.value)}
                className="w-full md:w-4/12 p-2 border border-gray-300 rounded mt-1"
              />
            </div>
            <div className="mb-4 flex flex-col">
              <label
                htmlFor="comments"
                className="text-gray-700 text-sm font-semibold"
              >
                Comments
              </label>
              <textarea
                id="comments"
                name="comments"
                rows="3"
                value={comments}
                onChange={(e) => setComments(e.target.value)}
                className="w-full md:w-4/12 p-2 border border-gray-300 rounded mt-1"
              ></textarea>
            </div>
            <button
              type="submit"
              className="w-full md:w-3/12 text-white bg-blue-500 hover:bg-blue-600 font-semibold p-2 rounded"
            >
              I commit to paying up to {offer || "0.00"}€
            </button>
          </form>
        </div>
      </Layout>
    </>
  );
};
export default GetRequest;
