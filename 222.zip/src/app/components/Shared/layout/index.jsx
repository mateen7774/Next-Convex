"use client";

import React, { useState, useEffect } from "react";
import FontFaceObserver from "fontfaceobserver";
import Header from "../../Header";
import Footer from "../../Footer";
import { useConvexAuth } from "convex/react";
import { useAuth0 } from "@auth0/auth0-react";
import { useRouter } from "next/navigation"; // Make sure this import is correct. It should be from "next/router"

const Layout = ({ children }) => {
  const { isLoading, isAuthenticated } = useConvexAuth();
  const [isFontLoaded, setIsFontLoaded] = useState(false);
  const router = useRouter();

  useEffect(() => {
    const oakesGroteskObserver = new FontFaceObserver("Oakes Grotesk Medium");
    const sfProDisplayObserver = new FontFaceObserver("SFProDisplayRegular");

    Promise.all([oakesGroteskObserver.load(), sfProDisplayObserver.load()])
      .then(() => {
        setIsFontLoaded(true);
      })
      .catch((error) => {
        console.error("One or more fonts are not available", error);
        setIsFontLoaded(true); // Consider setting a state to show an error message instead
      });

    // Ensure fonts are loaded and authentication status is known before deciding on rendering or redirection
    if (isFontLoaded && !isLoading) {
      if (!isAuthenticated) {
        // Redirect if not authenticated
        router.push("/");
      }
    }
  }, [isFontLoaded, isLoading, isAuthenticated, router]);

  if (!isFontLoaded || isLoading) {
    // Show spinner while loading fonts or authentication status
    return (
      <div className="flex justify-center items-center h-screen">
        <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-purple-500"></div>
      </div>
    );
  }

  return isAuthenticated ? (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">{children}</main>
      <Footer />
    </div>
  ) : null; // or return null to avoid rendering anything before redirect, but since we're redirecting, this won't be visible
};

export default Layout;
