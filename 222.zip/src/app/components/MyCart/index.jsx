"use client";
import { useState, useEffect } from "react";
import Layout from "../Shared/layout";

import { useMutation, useQuery } from "convex/react";
import { api } from "../../../../convex/_generated/api";
import toast, { Toaster } from "react-hot-toast";
const MyCart = () => {
  const getBasket = useQuery(api.basket.getBasket);

  const setInitialPayment = useMutation(api.payment.initialPayment);
  const [basket, setBasket] = useState([]);

  useEffect(() => {
    if (getBasket) {
      setBasket(getBasket);
    }
  }, [getBasket]); // Depend on getBasket.data to re-run this effect

  const paymentApi = async () => {
    await setInitialPayment({
      maxPrice: 34,
      deliveryLocation: "ewq  eqwe",
      deliveryTimeSlot: 2313,
      comments: "comments",
      conditions: "conditions",
    });
    toast.success("Add to cart successfully");
  };

  console.log(basket, "sas");

  const incrementQuantity = (productId) => {
    setBasket((current) =>
      current.map((product) =>
        product._id === productId
          ? { ...product, quantity: product.quantity + 1 }
          : product
      )
    );
  };

  const decrementQuantity = (productId) => {
    setBasket((current) =>
      current.map((product) =>
        product._id === productId
          ? { ...product, quantity: Math.max(product.quantity - 1, 1) }
          : product
      )
    );
  };

  const removeProduct = async (productId) => {
    console.log("productId", productId);
    setBasket((current) =>
      current.filter((product) => product._id !== productId)
    );
  };

  const totalQuantity = () => {
    const total = basket.reduce(
      (total, product) => total + product.quantity,
      0
    );
    sessionStorage.setItem("total", total);
  };
  totalQuantity();

  return (
    <>
      <Layout>
        <Toaster />
        <div
          style={{ fontFamily: "Oakes Grotesk Medium" }}
          className="container mx-auto p-6  mt-10"
        >
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
            <div className=" md:col-span-8 space-y-4 bg-white md:p-4 shadow-md rounded rounded-lg">
              {basket?.map((product, index) => (
                <div
                  key={index}
                  className="bg-white flex items-center shadow rounded-lg"
                >
                  <button
                    onClick={async () => {
                      removeProduct(product._id);
                    }}
                    className="text-red-500 hover:text-red-600 md:p-4 p-1"
                  >
                    <span>&times;</span>
                  </button>
                  <img
                    src={product.imageUrl}
                    alt="Product"
                    className="w-20 h-20 object-cover"
                  />
                  <div className="flex flex-row items-center justify-between w-full">
                    <div className="flex flex-col items-start  p-4 leading-normal">
                      <h5 className="text-lg mb-2">{product.name}</h5>
                      <p className="text-sm mb-2">{product.description}</p>
                      <p className="text-sm">{product.quantity}</p>
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 p-4">
                      <button
                        onClick={async () => {
                          decrementQuantity(product._id);
                        }}
                        className="text-gray-500 hover:text-gray-600"
                      >
                        <span>&ndash;</span>
                      </button>
                      <input
                        type="text"
                        className="text-center w-8"
                        value={product.quantity}
                        readOnly
                      />
                      <button
                        onClick={async () => {
                          incrementQuantity(product._id);
                        }}
                        className="text-gray-500 hover:text-gray-600"
                      >
                        <span>&#43;</span>
                      </button>
                    </div>
                    {console.log("prodicy", product.price)}
                    <div className="text-lg  p-4">
                      {product.price * product.quantity} €
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Right column for the form */}
            <div className="md:col-span-4 bg-white p-6 rounded-lg shadow-lg flex flex-col space-y-4">
              <div className="flex flex-wrap -mx-3 mb-2">
                <div className="w-full md:w-1/2 px-2 mb-6 md:mb-0">
                  <label
                    className="block uppercase tracking-wide text-gray-700 text-xs mb-2"
                    htmlFor="delivery-date"
                  >
                    Delivery Date
                  </label>
                  <input
                    className="appearance-none block w-full bg-white text-gray-700 border border-gray-300 rounded-lg py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-blue-500 text-xs"
                    id="delivery-date"
                    type="date"
                    value={new Date().toISOString().split("T")[0]} // Set current date as default value
                  />
                </div>

                <div className="w-full md:w-1/2 px-3">
                  <label
                    className="block uppercase tracking-wide text-gray-700 text-xs mb-2"
                    htmlFor="timeslot"
                  >
                    Timeslot
                  </label>
                  <div className="relative">
                    <select
                      className="block appearance-none w-full bg-white border border-gray-300 text-xs rounded-lg py-3 px-4 pr-8 leading-tight focus:outline-none focus:bg-white focus:border-blue-500"
                      id="timeslot"
                    >
                      <option>08:00-10:00</option>
                    </select>
                  </div>
                </div>
              </div>

              {["delivery-address", "comments", "conditions"].map((id) => (
                <div className="w-full  mb-6" key={id}>
                  <label
                    className="block  tracking-wide text-gray-700 text-xs  mb-2"
                    htmlFor={id}
                  >
                    {id
                      .split("-")
                      .map(
                        (word) => word.charAt(0).toUpperCase() + word.slice(1)
                      )
                      .join(" ")}
                  </label>
                  <textarea
                    className="appearance-none block w-full bg-white text-gray-700 border border-gray-300 rounded-lg py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-blue-500"
                    id={id}
                    type="text"
                    placeholder="Enter details here..."
                  ></textarea>
                </div>
              ))}

              <div className="flex flex-wrap -mx-3 mb-6">
                <div className="w-full md:w-1/2 px-3 mb-6 md:mb-0">
                  <label
                    className="block uppercase tracking-wide text-gray-700 text-xs  mb-2"
                    htmlFor="suggested-price"
                  >
                    Suggested Max. price
                  </label>
                  <input
                    className="appearance-none block w-full bg-white text-gray-700 border border-gray-300 rounded-lg py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-blue-500"
                    id="suggested-price"
                    type="text"
                    placeholder="4935"
                  />
                </div>
                <div className="w-full md:w-1/2 px-2">
                  <label
                    className="block uppercase tracking-wide text-gray-700 text-xs  mb-2"
                    htmlFor="your-price"
                  >
                    Your Max. price
                  </label>
                  <input
                    className="appearance-none block w-full bg-white text-gray-700 border border-gray-300 rounded-lg py-3 px-4 leading-tight focus:outline-none focus:bg-white focus:border-blue-500"
                    id="your-price"
                    type="text"
                    placeholder="4935"
                  />
                </div>

                <div className="w-full  px-2 mt-4">
                  <input type="checkbox" id="termsCheckbox" name="terms" />
                  <label
                    for="termsCheckbox"
                    className="ml-3"
                    style={{ fontSize: "14px" }}
                  >
                    I agree to the <a>Terms and Conditions</a>
                  </label>
                </div>
              </div>
              <div className="flex justify-center">
                <button
                  onClick={paymentApi}
                  className="w-5/5 bg-blue-500 hover:bg-blue-700 text-white  py-2 px-4 rounded shadow-md hover:shadow-lg transition duration-150 ease-in-out"
                >
                  I commit to paying up to € 18.200
                </button>
              </div>
            </div>
          </div>
        </div>
      </Layout>
    </>
  );
};
export default MyCart;
