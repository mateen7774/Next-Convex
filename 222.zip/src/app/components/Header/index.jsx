"use client";
import React, { useState, useEffect, useRef } from "react";
import "./header.css";
import Image from "next/image";
import Link from "next/link";
import { usePathname } from "next/navigation";

import { useAuth0 } from "@auth0/auth0-react";

import { useConvexAuth } from "convex/react";

const Loader = () => (
  <div className="flex justify-center items-center h-screen">
    <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-purple-500"></div>
  </div>
);

const Header = () => {
  const { loginWithRedirect, logout } = useAuth0();

  const { isLoading, isAuthLoading, isAuthenticated } = useConvexAuth();

  console.log("isAuthenticated", isLoading);

  const pathname = usePathname();
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [itemCount, setItemCount] = useState(0);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };
  const textColor = (path) => {
    return pathname === path ? "text-gradient" : "text-custom-gray";
  };

  const textColorMobile = (path) => {
    return pathname === path ? "text-gradient" : "text-white ";
  };

  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef();
  const isLoadingF = isAuthLoading;

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [dropdownRef]);

  useEffect(() => {
    console.log("isAuthenticated", isAuthenticated);

    setIsLoggedIn(isAuthenticated);
  }, [isAuthenticated]);
  const data = sessionStorage.getItem("total");
  useEffect(() => {
    const convertIntoNum = Number(data);
    setItemCount(convertIntoNum);
  }, [data]);

  if (isLoading) {
    return <Loader />;
  }

  return (
    <header
      style={{ fontFamily: "SFPRODISPLAYREGULAR" }}
      className="flex justify-between items-center p-1 bg-white shadow-md"
    >
      <Link href="/">
        <span className="flex items-center ml-5">
          <Image
            src="/logo.png"
            alt="Rocket Market Logo"
            width={50}
            height={50}
          />
          <h1
            className="text-xl text-gradient ml-2"
            style={{ fontWeight: "500" }}
          >
            Rocket Market
          </h1>
        </span>
      </Link>
      {isLoggedIn && (
        <nav className="hidden md:flex space-x-6 gap-8">
          <Link href="/home" passHref>
            <p className={`${textColor("/home")} transition duration-300`}>
              Home
            </p>
          </Link>
          <Link href="/products" passHref>
            <p className={`${textColor("/product")} transition duration-300`}>
              Products
            </p>
          </Link>
          <Link href="/requests" passHref>
            <p className={`${textColor("/request")}  transition duration-300`}>
              Requests
            </p>
          </Link>
        </nav>
      )}
      <div className="flex items-center">
        {isLoggedIn ? (
          <div className="flex items-center transition duration-300 gap-3 mr-5">
            <div className="relative inline-block">
              <Link href="/basket">
                <span className="block relative w-6 h-6">
                  <Image
                    src="/shopping-cart.svg"
                    alt="Shopping Cart Icon"
                    width={20}
                    height={20}
                  />
                  {itemCount > 0 && (
                    <span className="absolute top-1 right-1 inline-flex items-center justify-center h-4 w-4 text-xs font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-blue-600 rounded-full">
                      {itemCount}
                    </span>
                  )}
                </span>
              </Link>
            </div>

            <Image
              className="md:hidden cursor-pointer"
              src="/menu.svg"
              alt="menu"
              width={24}
              height={24}
              onClick={toggleSidebar}
            />

            <button className="hidden md:flex flex-col">Buyer</button>
            <div className="relative inline-block text-left" ref={dropdownRef}>
              <button
                onClick={() => setIsOpen(!isOpen)}
                className="flex items-center justify-center border-2 border-blue-400 text-blue-600 rounded-full h-6 w-6 p-4"
              >
                M
              </button>

              {isOpen && (
                <div className="origin-top-right absolute right-0 mt-1 w-48 rounded-xl shadow-lg bg-white ring-1 ring-black ring-opacity-5">
                  <div
                    className="py-1"
                    role="menu"
                    aria-orientation="vertical"
                    aria-labelledby="options-menu"
                  >
                    <a
                      onClick={() =>
                        logout({
                          logoutParams: {
                            returnTo: process.env.NEXT_PUBLIC_REDIRECT_URI,
                          },
                        })
                      }
                      className="block px-4 py-2 text-sm hover:bg-gray-100"
                      role="menuitem"
                    >
                      Logout
                    </a>
                  </div>

                  <div
                    className="py-1"
                    role="menu"
                    aria-orientation="vertical"
                    aria-labelledby="options-menu"
                  >
                    <Link href="/registration">
                      <span
                        className="block px-4 py-2 text-sm hover:bg-gray-100"
                        role="menuitem"
                      >
                        Registration
                      </span>
                    </Link>
                  </div>
                </div>
              )}
            </div>
          </div>
        ) : (
          <button
            onClick={loginWithRedirect}
            className="bg-blue-400 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300"
          >
            Login
          </button>
        )}
      </div>

      {/* Sidebar Overlay */}
      <div
        className={`fixed inset-0 bg-black bg-opacity-50 z-40 transition-opacity ${
          isSidebarOpen ? "opacity-100" : "opacity-0 pointer-events-none"
        }`}
        onClick={toggleSidebar}
      ></div>

      {/* Sidebar Panel */}
      <div
        className={`fixed top-0 left-0 z-50 w-64 h-full bg-gray-800 text-white p-5 transition-transform duration-300 ease-in-out transform ${
          isSidebarOpen ? "translate-x-0" : "-translate-x-full"
        }`}
      >
        <Link href="/">
          <span className="flex items-center mb-12">
            <Image
              src="/logo.png"
              alt="Rocket Market Logo"
              width={50}
              height={50}
            />
            <h1 className="text-2xl font-semibold ml-3">Rocket Market</h1>
          </span>
        </Link>

        <nav className="flex flex-col gap-5">
          {["/home", "/products", "/requests"].map((path) => (
            <Link key={path} href={path} passHref>
              <span
                className={` p-2 rounded-md transition duration-300 ease-in-out ${textColorMobile(
                  path
                )}`}
              >
                {path.substring(1).charAt(0).toUpperCase() + path.slice(2)}
              </span>
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
};

export default Header;
