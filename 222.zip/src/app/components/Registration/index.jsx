"use client";
import React from "react";
import Layout from "../Shared/layout";

import { api } from "../../../../convex/_generated/api";
import { useMutation } from "convex/react";

const Registration = () => {
  const creteTodo = useMutation(api.todo.createTask);

  const handleSubmit = (event) => {
    event.preventDefault();
    creteTodo({
      text: "mateen",
    });
  };

  return (
    <Layout>
      <div
        style={{ fontFamily: "Oakes Grotesk Medium" }}
        className="rounded-lg flex items-center justify-center min-h-screen bg-gray-100 py-10"
      >
        <div className="px-8 py-6 text-left bg-white shadow-lg rounded-lg w-full max-w-2xl">
          <h3 className="text-2xl  text-center mb-4">Registration</h3>

          <h3 className="text-xl mt-6 mb-8">General Information</h3>

          <form onSubmit={handleSubmit}>
            <div className="mb-4">
              <p
                style={{ fontWeight: 400, fontSize: "15px" }}
                className="block mb-1 font-normal"
                htmlFor="role"
              >
                Select Role
              </p>

              <select
                id="role"
                className="w-full px-4 py-2 border border-[linear-gradient(to_right,#428FF5,#0064E8)] bg-light-blue rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="seller">Seller</option>
                <option value="buyer">Buyer</option>
                {/* Add other roles as needed */}
              </select>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
              <div>
                <label
                  style={{ fontWeight: 400, fontSize: "15px" }}
                  className="block mb-1 "
                  htmlFor="email"
                >
                  Email Address
                </label>
                <input
                  id="email"
                  type="email"
                  placeholder="xyz@gmail.com"
                  className="w-full px-4 py-2 border border-[linear-gradient(to_right,#428FF5,#0064E8)] bg-light-blue rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label
                  style={{ fontWeight: 400, fontSize: "15px" }}
                  className="block mb-1 "
                  htmlFor="phone"
                >
                  Phone Number
                </label>
                <input
                  id="phone"
                  type="tel"
                  placeholder="xxxx xxxxx"
                  className="w-full px-4 py-2 border rounded-xl focus:outline-none focus:ring-2 border-[linear-gradient(to_right,#428FF5,#0064E8)] bg-light-blue focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
            </div>

            <h3 className="text-xl  my-10">Company Information</h3>

            <div className=" mb-4">
              <div>
                <label
                  style={{ fontWeight: 400, fontSize: "15px" }}
                  className="block mb-1 "
                  htmlFor="company"
                >
                  Company Name
                </label>
                <input
                  id="company"
                  type="text"
                  placeholder="XYZ Company"
                  className="border-[linear-gradient(to_right,#428FF5,#0064E8)] bg-light-blue w-full px-4 py-2 border rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
            </div>

            <div className=" mb-4">
              <div>
                <label
                  style={{ fontWeight: 400, fontSize: "15px" }}
                  className="block mb-1 "
                  htmlFor="address"
                >
                  Address
                </label>
                <textarea
                  id="address"
                  type="text"
                  placeholder="2533 Camille Overpass, Roganhfield"
                  className="border-[linear-gradient(to_right,#428FF5,#0064E8)] bg-light-blue w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent h-24 resize-none"
                  required
                  style={{ minHeight: "64px", maxHeight: "64px" }}
                ></textarea>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
              <div>
                <label
                  style={{ fontWeight: 400, fontSize: "15px" }}
                  className="block mb-1"
                  htmlFor="registrationNumber"
                >
                  Registration Number
                </label>
                <input
                  id="registrationNumber"
                  type="text"
                  placeholder="861941903100"
                  className="border-[linear-gradient(to_right,#428FF5,#0064E8)] bg-light-blue w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <div>
                <label
                  style={{ fontWeight: 400, fontSize: "15px" }}
                  className="block mb-1 "
                  htmlFor="vatNumber"
                >
                  VAT Number
                </label>
                <input
                  id="vatNumber"
                  type="text"
                  placeholder="AD123456464"
                  className="border-[linear-gradient(to_right,#428FF5,#0064E8)] bg-light-blue w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                />
              </div>
              <div class="terms-and-conditions">
                <input type="checkbox" id="termsCheckbox" name="terms" />
                <label
                  for="termsCheckbox"
                  className="ml-3"
                  style={{ fontSize: "14px" }}
                >
                  I agree to the <a>Terms and Conditions</a>
                </label>
              </div>
            </div>

            <div className="flex justify-center mt-6">
              <button
                type="submit"
                className="px-6 py-2 leading-5 text-white transition-colors duration-200 transform bg-[linear-gradient(to_right,#428FF5,#0064E8)] rounded-md hover:bg-blue-700 focus:outline-none focus:bg-blue-700"
              >
                Register
              </button>
            </div>
          </form>
        </div>
      </div>
    </Layout>
  );
};

export default Registration;
