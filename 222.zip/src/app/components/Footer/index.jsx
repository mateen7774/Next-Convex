import React from "react";

const Footer = () => {
  return (
    <footer
      style={{ fontFamily: "SFPRODISPLAYREGULAR" }}
      className="bg-custom-blue text-white p-2 text-center text-sm"
    >
      © Rocket Market etc.
    </footer>
  );
};

export default Footer;
