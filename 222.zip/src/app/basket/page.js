import MyCart from "../components/MyCart";
export default MyCart;
