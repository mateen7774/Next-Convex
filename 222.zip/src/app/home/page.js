import HomeCard from "../components/HomeCard";

export default HomeCard;
