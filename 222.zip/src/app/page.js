"use client";

import React, { useState, useEffect } from "react";

import Header from "./components/Header";
import Footer from "./components/Footer";
import Home from "./components/Home";

import FontFaceObserver from "fontfaceobserver";

import { Authenticated, Unauthenticated, AuthLoading } from "convex/react";

const HomePage = () => {
  const [isFontLoaded, setIsFontLoaded] = useState(false);

  useEffect(() => {
    const oakesGroteskObserver = new FontFaceObserver("Oakes Grotesk Medium");
    const sfProDisplayObserver = new FontFaceObserver("SFProDisplayRegular");

    Promise.all([oakesGroteskObserver.load(), sfProDisplayObserver.load()])
      .then(() => {
        setIsFontLoaded(true);
      })
      .catch((error) => {
        console.error("One or more fonts are not available", error);

        setIsFontLoaded(true);
      });
  }, []);

  const Spinner = () => (
    <div className="flex justify-center items-center h-screen">
      <div className="animate-spin rounded-full h-16 w-16 border-t-4 border-b-4 border-purple-500"></div>
    </div>
  );

  if (!isFontLoaded) {
    return <Spinner />;
  }

  return (
    <div className="flex flex-col min-h-screen">
      <Header />
      <main className="flex-grow">
        <Home />
      </main>
      <Footer />
    </div>
  );
};

export default HomePage;
