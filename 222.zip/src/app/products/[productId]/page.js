import InsulationProduct from "../../components/InsulationProduct";
export default InsulationProduct;
