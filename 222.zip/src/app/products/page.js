import Product from "../components/Product";
export default Product;
