import GetRequest from "../../components/GetRequest";
export default GetRequest;
